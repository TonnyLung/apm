## 8.0.1

#### OAP-Backend
* Fix `no-init` mode is not working in ElasticSearch storage.
