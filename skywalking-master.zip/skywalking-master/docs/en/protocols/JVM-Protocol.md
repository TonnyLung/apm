# JVM Metrics Service
## Abstract
Uplink the JVM metrics, including PermSize, HeapSize, CPU, Memory, etc., every second.

[gRPC service define](https://github.com/apache/skywalking-data-collect-protocol/blob/master/language-agent/JVMMetric.proto)
